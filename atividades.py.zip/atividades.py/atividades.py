
# Atividade 01
class Pilha:
    def _init_(self):
        self.items = []

    def empilhar(self, item):
        self.items.append(item)

    def desempilhar(self):
        if not self.esta_vazia():
            return self.items.pop()

    def topo(self):
        if not self.esta_vazia():
            return self.items[-1]

    def esta_vazia(self):
        return len(self.items) == 0

    def exibir_pilha(self):
        print("Pilha:", self.items)

    def esvaziar(self):
        self.items = []

def main():
    pilha = Pilha()

    while True:
        print("\nEDITOR DE LISTAS")
        print("1-EMPILHAR\n2-DESEMPILHAR\n3-EXIBIR ELEMENTO DO TOPO")
        print("4-EXIBIR A PILHA\n5-ESVAZIAR A PILHA\n6-SAIR")
        opcao = input("DIGITE SUA OPÇÃO: ")

        if opcao == "1":
            item = int(input("Digite o elemento a ser empilhado: "))
            pilha.empilhar(item)
        elif opcao == "2":
            desempilhado = pilha.desempilhar()
            if desempilhado is not None:
                print("Elemento desempilhado:", desempilhado)
            else:
                print("A pilha está vazia.")
        elif opcao == "3":
            topo = pilha.topo()
            if topo is not None:
                print("Elemento do topo:", topo)
            else:
                print("A pilha está vazia.")
        elif opcao == "4":
            pilha.exibir_pilha()
        elif opcao == "5":
            pilha.esvaziar()
            print("A pilha foi esvaziada.")
        elif opcao == "6":
            print("Encerrando o programa.")
            break
        else:
            print("Opção inválida.")

if __name__ == "__main__":
  main()

# Atividade 02
 class ContaBancaria:
    def __init__(self, numero, saldo_inicial):
       self.numero = numero
       self.saldo = saldo_inicial

    def depositor(self, valor):
        if valor > 0:
            self.saldo += valor
            print(f"Deposito de {valor} realizado com sucesso.")
        else:
            print("valor dwe deposito invalido.")

    def sacar(self, valor):
        if  valor > 0 and valor <=self.saldo:
             self.saldo -= valor
             print(f"saque de {valor} realizado com sucesso.")

        else:
             print("saldo insuficiente ou valor de saque invalido.")

    def imprimir_saldo(self):
        print(f"saldo atual da conta {self.numero}: {self.saldo}")


conta = ContaBancaria("12345", 1000)

print("conta bancaria criada com sucesso. ")
conta.imprimir_saldo()

conta.depositor(500)
conta.imprimir_saldo()

conta.sacar(300)
conta.imprimir_saldo()

conta.sacar(1500)

# questao 03
def main() :
    a = 3.14
    print("%f" % a)

    p = None
    p = [0] * 1
    p[0] = 2.718
    print("%f" % a)

    a = 5
    print("%f" % p[0])

    p[0] = 20
    q = p
    print("%f" % p[0])
    print("%f" % a)
    print("%f" % q[0])

if __name__== "__main__":
    main()